/** Automatically generated file. DO NOT MODIFY */
package com.example.studentmanagment;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}